from pandas.core._numba.kernels.mean_ import sliding_mean

__all__ = ["sliding_mean"]
