import json,boto3,csv,uuid,os
import pandas as pd
import numpy as np

from io import StringIO

def findKeys(keys,data):
    for item in data[0]['measurements']:
        keys_temp = list(item['series'].keys())
        key = keys_temp[1]
        keys.append(key) 
    return keys
def flatten_json(y):
    out = {}

    def flatten(x,name=''):
        if type(x) is dict:
            for a in x:
                if a != "computed":
                    flatten(x[a],name + a +'_')
        elif type(x) is list:
            i = 0
            for a in x:
                flatten(a,name + str(i) + '_')
                i += 1
        else:
            out[name[:-1]] = x

    flatten(y)
    return out 
def formatFlattenJson(flat_data,keys,filename):
    results = []
    temp_time_list = []
    for item in flat_data:

        if item.count("_") <= 1:
            val_ts = flat_data[item]
        elif item.count("_") > 1:
            id_dynamic_key = item[item.rfind("_")+1:len(item)]
            if item.find("$_time") != -1:
                temp_time_list.append(flat_data[item])
            elif item.find("$_time") == -1:
                key_attr = item[item.find("series_"):item.rfind("_")]
                key_attr = key_attr[key_attr.find("_")+1:len(key_attr)]
                val_dynamic = flat_data[item]
                rowid = uuid.uuid4()
                dataset = {
                    "id":str(rowid),
                    "ts":str(val_ts),
                    "$_time": temp_time_list[int(id_dynamic_key)],
                    key_attr:str(val_dynamic)  
                }       
                results.append(dataset)
                
                if len(temp_time_list) -1 == int(id_dynamic_key):
                    del temp_time_list[:] 
    uploadCsvS3(results,keys,filename)    
    flat_data = {} 
    del results[:] 
    del temp_time_list[:]  
  
def uploadCsvS3(result,keys,filename):
    
    df = pd.DataFrame(result)
    #df.reset_index(drop=True,inplace=True)
    
    csv_buffer = StringIO()
    df.to_csv(csv_buffer,index=False)
    s3_resource = boto3.resource('s3')
    s3_resource.Object("s3-nttdatatr-global-bshcdl-sensordata","data/"+filename+".csv").put(Body=csv_buffer.getvalue())
    print("done")
    
def run(collection_key,collection_file,keys):
    
    flat_data = {} 
    for collection_body in collection_file:
        flat_data = flatten_json(collection_body['measurements'])
        formatFlattenJson(flat_data,keys,collection_key)
     
def lambda_handler(event, context):
    keys=["id","ts","$_time"]
    BUCKET_NAME = os.environ.get('BUCKET_NAME')
    s3_client = boto3.client('s3')

    # TODO implement
    records = event['Records'][0]
    file_detail = records['s3']['object']
    
    
    file_detail = str(file_detail['key'])
    filename = file_detail[file_detail.find("/")+1:file_detail.find(".json")]
    
    obj = s3_client.get_object(Bucket=BUCKET_NAME,Key=file_detail)
    
    #print(obj.key)
    body_str = obj['Body'].read().decode('utf-8')
    
    #str_data = body_str.split('{"content-spec"')
    str_data = "["+body_str+"]" 
    temp_text = str_data.replace('\n','').replace('\r','').replace('\t','').replace(' ','').strip()
    str_data = temp_text.replace('}{"content-spec":','},{"content-spec":')
    body_json = json.loads(str_data)
    
    r_keys = findKeys(keys,body_json)
    
    
    run(filename,body_json,r_keys) 
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
